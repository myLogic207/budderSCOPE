// rawBudderCUSTOMv0.1.0/Example
const eLogPath = require("../../config.json").eLog.eLogPath;
const { eLog } = require(eLogPath);