const eLogPath = require("../../config.json").eLog.eLogPath;
const { eLog } = require(eLogPath);